package com.satyayoganand.androidnotes;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

import org.json.JSONArray;
import org.json.JSONException;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;

public class MainActivity extends AppCompatActivity implements View.OnLongClickListener,View.OnClickListener {
    private static final String TAG = "MainActivity";

    private final ArrayList<Notes> NoteList = new ArrayList<>();
    private RecyclerView recyclerView;
    private NotesListAdapter notesListAdapter;


    private ActivityResultLauncher<Intent> activityResultLauncher;
    private Notes currentNote;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        recyclerView = findViewById(R.id.Recycler);
        notesListAdapter = new NotesListAdapter(this, NoteList);
        recyclerView.setAdapter(notesListAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        loadDataFromFile();
       // if (NoteList.isEmpty()) {
       //         NoteList.add(new Notes("Note2","ABCDEFGHIJKLMN",System.currentTimeMillis()));
           // setTitle(getString(R.string.app_name) + " [" + NoteList.size() + "]");

       // }
        activityResultLauncher = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), this::handleResult);
    }

    public void handleResult(ActivityResult result) {
        if (result == null || result.getData() == null) {
            Log.d(TAG, "handleResult: NULL ActivityResult received");
            return;
        }
        Intent data = result.getData();
        if (result.getResultCode() == RESULT_OK) {

            if (data.hasExtra("NEW_NOTE")) {
                Notes s = (Notes) data.getSerializableExtra("NEW_NOTE");
                NoteList.add(s);
                Collections.sort(NoteList);
                notesListAdapter.notifyItemRangeChanged(0, NoteList.size());
            } else if (data.hasExtra("EDIT_NOTE")) {
                Notes s = (Notes) data.getSerializableExtra("EDIT_NOTE");
                currentNote.setNoteHeader(s.getNoteHeader());
                currentNote.setNotes(s.getNotes());
                currentNote.setDate(s.getDate());
                Collections.sort(NoteList);
                notesListAdapter.notifyItemRangeChanged(0, NoteList.size());
            }
        }
    }

    @Override
    public boolean onCreateOptionsMenu(@NonNull Menu menu) {
        getMenuInflater().inflate(R.menu.action_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        if (item.getItemId() == R.id.Add) {
            Intent intent = new Intent(this, NewNoteActivity.class);
            activityResultLauncher.launch(intent);
            setTitle(getString(R.string.app_name) + " [" + NoteList.size() + "]");
            return true;
        }
         else if (item.getItemId() == R.id.About) {
            Intent intent = new Intent(this, AboutActivity.class);
            startActivity(intent);
            return true;
        } else {
            return super.onOptionsItemSelected(item);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        saveDataToFile();
    }

    private void saveDataToFile() {
        Log.d(TAG, "loadDataFromFile: " + NoteList.size());

        JSONArray jsonArray = new JSONArray();
        for (Notes note : NoteList) {
            try {
                jsonArray.put(note.toJSON());
            } catch (JSONException e) {
                Log.d(TAG, "saveDataToFile: " + e.getMessage());
                e.printStackTrace();
            }
        }
        try {
            FileOutputStream fos = getApplicationContext().openFileOutput("JSONText.json", MODE_PRIVATE);
            PrintWriter pr = new PrintWriter(fos);
            pr.println(jsonArray);
            pr.close();
            fos.close();
        } catch (Exception e) {
            Log.d(TAG, "saveDataToFile: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void loadDataFromFile() {
        FileInputStream fis;
        try {
            fis = getApplicationContext().openFileInput("JSONText.json");
        } catch (FileNotFoundException e) {
            Log.d(TAG, "loadDataFromFile: " + e.getMessage());
            e.printStackTrace();
            return;
        }
        StringBuilder fileContent = new StringBuilder();

        try {
            byte[] buffer = new byte[1024];
            int n;
            while ((n = fis.read(buffer)) != -1) {
                fileContent.append(new String(buffer, 0, n));
            }
            JSONArray jsonArray = new JSONArray(fileContent.toString());
            Log.d(TAG, "readFromFile: ");
            for (int i = 0; i < jsonArray.length(); i++) {
                NoteList.add(Notes.createFromJSON(jsonArray.getJSONObject(i)));
            }
        } catch (Exception e) {
            Log.d(TAG, "loadDataFromFile: " + e.getMessage());
            e.printStackTrace();
            return;
        }
        Log.d(TAG, "loadDataFromFile: " + NoteList.size());
        setTitle(getString(R.string.app_name) + " [" + NoteList.size() + "]");
    }

    @Override
    public void onClick(View v) {
        Intent intent = new Intent(this, NewNoteActivity.class);

        Log.d(TAG, "onClick: ");
        int pos = recyclerView.getChildLayoutPosition(v);
        currentNote = NoteList.get(pos);

        intent.putExtra("EDIT_NOTE", currentNote);
        activityResultLauncher.launch(intent);
    }

    @Override
    public boolean onLongClick(View view) {
        Log.d(TAG, "onLongClick: Main");

        AlertDialog.Builder builder = new AlertDialog.Builder(this);


        builder.setPositiveButton("YES", (dialog, id) -> {
            int position = recyclerView.getChildLayoutPosition(view);
            NoteList.remove(position);
            notesListAdapter.notifyItemRemoved(position);
            saveDataToFile();


            setTitle(getString(R.string.app_name) + " [" + NoteList.size() + "]");
        });
        builder.setNegativeButton("NO", (dialog, id) -> {});
        int position = recyclerView.getChildLayoutPosition(view);

        builder.setTitle("Unsaved Data");
        builder.setMessage("Do you want to save the changes you made? Save note '"+NoteList.get(position).getNoteHeader() +"' ?");

        AlertDialog dialog = builder.create();
        dialog.show();

        return true;
    }

    @Override
    public void onBackPressed() {
        Log.d(TAG, "onBackPressed: ");

        super.onBackPressed();
    }


}

