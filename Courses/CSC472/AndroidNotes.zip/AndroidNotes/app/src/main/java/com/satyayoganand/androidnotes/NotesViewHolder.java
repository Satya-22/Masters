package com.satyayoganand.androidnotes;

import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class NotesViewHolder extends RecyclerView.ViewHolder {

    TextView NoteHeader;
    TextView Notes;
    TextView date;
    public NotesViewHolder(@NonNull View itemView) {
        super(itemView);

        NoteHeader = itemView.findViewById(R.id.NoteHeader);
        Notes = itemView.findViewById(R.id.Notes);
        date = itemView.findViewById(R.id.DateModified);
    }
}
