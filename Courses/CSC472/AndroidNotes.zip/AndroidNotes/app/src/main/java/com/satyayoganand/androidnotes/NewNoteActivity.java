package com.satyayoganand.androidnotes;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.EditText;

public class NewNoteActivity extends AppCompatActivity {

    private static final String TAG = "NewNoteActivity";

    private EditText NoteHeader;
    private EditText Notes;
    private String notePrevious;
    private String noteHeaderPrevious;
    private Long noteDate;
    private String headerStr;
    private String intentType;


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        Log.d(TAG, "onCreate: ");

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_note);
        NoteHeader = findViewById(R.id.NoteHeader_AddNote);
        Notes = findViewById(R.id.Note_AddNote);

        if (getIntent().hasExtra("EDIT_NOTE")) {
            Notes N = (Notes) getIntent().getSerializableExtra("EDIT_NOTE");
            Log.d(TAG, "onCreate: NoteHeader " + NoteHeader);
            Log.d(TAG, "onCreate: Changed NoteHeader " + N.getNoteHeader());
            noteHeaderPrevious = N.getNoteHeader();
            notePrevious = N.getNotes();
            NoteHeader.setText(N.getNoteHeader());
            Notes.setText(N.getNotes());
            noteDate = N.getDate();
            Log.d(TAG, "onCreate: NOTE date : " + noteDate);
        }

    }

    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.new_note_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == R.id.save_btn) {
            if (NoteHeader.getText().toString().isEmpty()) {
                AlertDialog.Builder builder = new AlertDialog.Builder(this);

                builder.setPositiveButton("Ok", (dialog, which) -> {
                    super.onBackPressed();
                });
                builder.setNegativeButton("Cancel", (dialog, id) ->  dialog.dismiss());
                builder.setTitle("User note will not be saved without a title");

                AlertDialog dialog = builder.create();
                dialog.show();


            } else if (!NoteHeader.getText().toString().isEmpty()) {

                Intent intent = new Intent();
                if(getIntent().hasExtra("EDIT_NOTE")){
                    intentType = "EDIT_NOTE";
                }
                else{
                    intentType = "NEW_NOTE";
                }

                Notes N = doDataReturn();
                if (N != null) {

                    if (getIntent().hasExtra("EDIT_NOTE")){
                        intent.putExtra("EDIT_NOTE", N);
                        intentType = "EDIT_NOTE";
                    }
                    else {
                        intent.putExtra("NEW_NOTE", N);
                        intentType = "NEW_NOTE";
                    }
                    setResult(RESULT_OK, intent);
                }
                finish();
            }
        }
        return super.onOptionsItemSelected(item);
    }

    private Notes doDataReturn() {

        Long dateModified = noteDate;
        headerStr = NoteHeader.getText().toString();
        Log.d(TAG, "doDataReturn: NoteHeader :" + headerStr);
        Log.d(TAG, "doDataReturn: NoteChanged : "+ noteHeaderPrevious);
        if (headerStr.trim().isEmpty()) {
            Log.d(TAG, "onOptionsItemSelected: Name Empty");
            return null;
        }
        String noteStr = Notes.getText().toString();
        if (noteStr.trim().isEmpty()) {
            Log.d(TAG, "onOptionsItemSelected: Id Empty");
            return null;
        }
        if(intentType == "EDIT_NOTE"){
            if ((!noteHeaderPrevious.equals(headerStr)) || (!notePrevious.equals(noteStr))) {
                dateModified = System.currentTimeMillis();
                Log.d(TAG, "doDataReturn: Date Modified :" + dateModified);
                return new Notes(headerStr, noteStr, dateModified);
            }
            return null;
        }
        else if(intentType == "NEW_NOTE"){
                Log.d(TAG, "doDataReturn: Date Modified :" + dateModified);
                return new Notes(headerStr, noteStr, System.currentTimeMillis());
        }

        return null;
    }

    @Override
    public void onBackPressed() {

        AlertDialog.Builder builder = new AlertDialog.Builder(this);

        builder.setPositiveButton("YES", (dialog, id) -> {

            Intent intent = new Intent();
            if (getIntent().hasExtra("EDIT_NOTE")) {
                intentType = "EDIT_NOTE";
            }
            else {
                intentType = "NEW_NOTE";
            }
           Notes N = doDataReturn();
            if (N != null) {
                Log.d(TAG, "onBackPressed: Pressed Yes :"+N.getDate());
                if (getIntent().hasExtra("EDIT_NOTE")) {
                    intent.putExtra("EDIT_NOTE", N);
                }
                else {
                    intent.putExtra("NEW_NOTE", N);
                }
                setResult(RESULT_OK, intent);
            }
            super.onBackPressed();
        });
        builder.setNegativeButton("NO", (dialog, id) -> super.onBackPressed());
        builder.setTitle("Unsaved Data !!!");
        builder.setMessage("Your Note is not saved! Save note '"+"' ?");

        AlertDialog dialog = builder.create();
        dialog.show();


    }
}