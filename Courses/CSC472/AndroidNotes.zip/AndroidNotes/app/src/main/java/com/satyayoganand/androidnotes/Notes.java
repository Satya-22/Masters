package com.satyayoganand.androidnotes;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.Serializable;

public class Notes implements Comparable<Notes>,Serializable {

    private String noteHeader;
    private String notes;
    private long date;


    public Notes(String noteHeader, String notes, long date) {
        this.noteHeader = noteHeader;
        this.notes = notes;
        this.date = date;
    }

    public JSONObject toJSON() throws JSONException {
        JSONObject note = new JSONObject();

        note.put("NoteHeader", noteHeader);
        note.put("Notes", notes);
        note.put("Date", date);
        return note;
    }

    public String getNoteHeader() {
        return noteHeader;
    }

    public String getNotes() {
        return notes;
    }

    public long getDate() {
        return date;
    }

    public void setDate(long date){ this.date = date;}


    public void setNoteHeader(String noteHeader){
        this.noteHeader = noteHeader;
    }

    public void setNotes(String notes){
        this.notes = notes;
    }




    public static Notes createFromJSON(JSONObject jsonObject) throws JSONException {
        String noteHeader = jsonObject.getString("NoteHeader");
        String notes = jsonObject.getString("Notes");
        Long dateModified = jsonObject.getLong("Date");

        return new Notes(noteHeader, notes, dateModified);
    }

    @Override
    public int compareTo(Notes notes) {
        return (int) (notes.date - date);
    }
}
