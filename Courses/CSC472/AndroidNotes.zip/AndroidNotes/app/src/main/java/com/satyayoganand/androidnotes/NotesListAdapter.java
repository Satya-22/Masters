package com.satyayoganand.androidnotes;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class NotesListAdapter  extends RecyclerView.Adapter<NotesViewHolder> {
    private static final String TAG = "NotesListAdapter";

    private MainActivity mainActivity;
    private ArrayList<Notes> notesArrayList;

    private final SimpleDateFormat sdf =
            new SimpleDateFormat("EEE MMM d, h:mm a", Locale.getDefault());

    public NotesListAdapter(MainActivity mainActivity, ArrayList<Notes> notesArrayList) {
        this.mainActivity = mainActivity;
        this.notesArrayList = notesArrayList;
    }

    @NonNull
    @Override
    public NotesViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.list_entry, parent, false);
        itemView.setOnLongClickListener(mainActivity);
        itemView.setOnClickListener(mainActivity);
        return new NotesViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull NotesViewHolder holder, int position) {
        Log.d(TAG, "onBindViewHolder: ");
        Notes note = notesArrayList.get(position);
        Log.d(TAG, "onBindViewHolder: header Length : "+note.getNoteHeader().length());
        if(note.getNoteHeader().length()<80) {
            holder.NoteHeader.setText(note.getNoteHeader());

        }
        else{
            holder.NoteHeader.setText((note.getNoteHeader().substring(0,80)) + "...");
        }
        if(note.getNotes().length()<80) {
            holder.Notes.setText(note.getNotes());
        }
        else{
            holder.Notes.setText((note.getNotes().substring(0,80)) +"...");
        }
        holder.date.setText(sdf.format(new Date(note.getDate())));
    }

    @Override
    public int getItemCount() {
        return notesArrayList.size();
    }
}
