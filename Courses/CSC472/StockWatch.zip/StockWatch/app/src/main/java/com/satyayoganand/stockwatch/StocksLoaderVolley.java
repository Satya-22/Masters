package com.satyayoganand.stockwatch;


import android.net.Uri;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Collections;
import java.util.HashMap;

public class StocksLoaderVolley {

    private static RequestQueue queue;
    private static MainActivity mainActivity;

    private static final String DATA_URL = "https://cloud.iexapis.com/stable/stock/";
    private static final String api_token ="pk_ed46c6a524444231ac88933cc2e0b21c";



    public static void downloadStock(MainActivity m,String s) {

        mainActivity = m;

        RequestQueue queue = Volley.newRequestQueue(mainActivity);

        Uri.Builder buildURL = Uri.parse(DATA_URL).buildUpon();
        buildURL.appendPath(s);
        buildURL.appendPath("quote");
        buildURL.appendQueryParameter("token", api_token);

        String urlToUse = buildURL.build().toString();

        Response.Listener<JSONObject> listener =
                response -> parseJSON(response,mainActivity);

        Response.ErrorListener error =
                error1 -> parseJSON(null,mainActivity);


        JsonObjectRequest jsonObjectRequest =
                new JsonObjectRequest(Request.Method.GET, urlToUse, null, listener, error);

        queue.add(jsonObjectRequest);

    }


    private static void parseJSON(JSONObject jsonObject,MainActivity m)  {

        try {
            if(jsonObject.equals(null)){
                return;
            } else{
                String stockSymbol = jsonObject.getString("symbol");
                String companyName = jsonObject.getString("companyName");
                double price = jsonObject.getDouble("latestPrice");
                double priceChange = jsonObject.getDouble("change");
                double changePercent = jsonObject.getDouble("changePercent");

                MainActivity.stockList.add(new Stocks(stockSymbol,companyName,price,priceChange,changePercent));
                Collections.sort(MainActivity.stockList);
                mainActivity.FillJson();

                MainActivity.stocksListAdapter.notifyItemRangeChanged(0,MainActivity.stockList.size());

            }

        }catch (Exception e){
            e.printStackTrace();
        }
    }



}
