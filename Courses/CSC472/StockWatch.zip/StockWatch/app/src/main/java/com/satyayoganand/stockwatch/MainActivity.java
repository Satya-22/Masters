package com.satyayoganand.stockwatch;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.util.Log;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;


import org.json.JSONArray;
import org.json.JSONException;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;

import java.util.Locale;
import java.util.Map;

public class MainActivity extends AppCompatActivity implements View.OnClickListener,View.OnLongClickListener {


    private static  final String TAG ="MainActivity";

    private RecyclerView recyclerView;

    public static final ArrayList<Stocks> stockList = new ArrayList<>();

    public static StocksListAdapter stocksListAdapter;
    private SwipeRefreshLayout swiper;
    private Stocks currentStock;
    private EditText symbol2;

    private String text;

    private HashMap<String,String> hashMap;

    private static ArrayList<String> selectedRecords = new ArrayList<>();

    private String stockURL ="https://www.marketwatch.com/investing/stock/";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        recyclerView = findViewById(R.id.Recycler);

        stocksListAdapter = new StocksListAdapter( this,stockList);
        recyclerView.setAdapter(stocksListAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setItemAnimator(null);



        swiper = findViewById(R.id.swiper);
        swiper.setOnRefreshListener(this::doRefresh);


        try {
            readJson();
            stocksListAdapter.notifyItemRangeChanged(0,stockList.size());
        } catch (Exception e) {
            e.printStackTrace();
        }

        stocksListAdapter.notifyItemRangeChanged(0,stockList.size());

        StockDownloader.getStockData(this);
        hashMap = StockDownloader.getNamesHash();

        doRefresh();
        stocksListAdapter.notifyItemRangeChanged(0,stockList.size());
    }

    private boolean hasNetworkConnection() {
        ConnectivityManager connectivityManager = getSystemService(ConnectivityManager.class);
        NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();
        return (networkInfo != null && networkInfo.isConnectedOrConnecting());
    }

    private void doRefresh() {

        if(hasNetworkConnection()) {

            ArrayList<Stocks> tempList = new ArrayList<>(stockList);
            stockList.clear();

            for (Stocks s : tempList) {
                StocksLoaderVolley.downloadStock(MainActivity.this, s.getStock_Symbol());
                stocksListAdapter.notifyItemRangeChanged(0,stockList.size());
            }
            tempList.clear();

            swiper.setRefreshing(false);

        } else{
            AlertDialog.Builder builderS1 = new AlertDialog.Builder(this);
            builderS1.setTitle("No Network Connection");
            builderS1.setMessage("Stocks Can't be updated without a network connection");
            builderS1.show();
            swiper.setRefreshing(false);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        try {
            FillJson();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(@NonNull Menu menu){
        getMenuInflater().inflate(R.menu.action_menu,menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item){

        selectedRecords.clear();

        if(item.getItemId() ==R.id.Add) {
            if (hasNetworkConnection()) {
                symbol2 = new EditText(this);
                symbol2.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS);
                symbol2.setGravity(Gravity.CENTER);

                AlertDialog.Builder builder = new AlertDialog.Builder(this);
                builder.setPositiveButton("ok", (dialog, which) -> {
                    text = symbol2.getText().toString();

                    for (Map.Entry<String, String> record : hashMap.entrySet()) {
                        if (record.getKey().toLowerCase(Locale.ROOT).contains(text.toLowerCase(Locale.ROOT)) || record.getValue().toLowerCase(Locale.ROOT).contains(text.toLowerCase(Locale.ROOT))) {
                            selectedRecords.add(record.getKey() + ":" + record.getValue());
                        }
                    }

                    if(selectedRecords.size()==0){
                        AlertDialog.Builder builder4 = new AlertDialog.Builder(this);
                        builder4.setTitle("Symbol not found : "+ text);
                        builder4.setMessage("No data for Stock Symbol");
                        builder4.show();
                        return;
                    }
                    else if (selectedRecords.size() == 1) {
                        String t =selectedRecords.get(0);

                        t = t.split(":")[0];


                        for(Stocks tempStock : stockList){
                            if(t.toLowerCase(Locale.ROOT).equals(tempStock.getStock_Symbol().toLowerCase(Locale.ROOT))){
                                AlertDialog.Builder builder3 = new AlertDialog.Builder(this);
                                builder3.setTitle("Duplicate Stock");
                                builder3.setMessage("Stock Symbol "+tempStock.getStock_Symbol()+" is already displayed");
                                builder3.show();
                                return;
                            }
                        }
                        StocksLoaderVolley.downloadStock(MainActivity.this,t);

                    } else {

                        CharSequence[] charSequences = selectedRecords.toArray(new CharSequence[selectedRecords.size()]);
                        AlertDialog.Builder builderS = new AlertDialog.Builder(this);
                        builderS.setTitle("Make a selection");

                        builderS.setItems(charSequences, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int poi) {


                                String s  = selectedRecords.get(poi);
                                s = s.split(":")[0];
                                s =s.trim();
                                for(Stocks tempStock : stockList){
                                    tempStock.getStock_Symbol();
                                    if(s.toLowerCase(Locale.ROOT).equals(tempStock.getStock_Symbol().toLowerCase(Locale.ROOT))){
                                        AlertDialog.Builder alertbuilder2 = new AlertDialog.Builder(MainActivity.this);
                                        alertbuilder2.setTitle("Duplicate Stock");
                                        alertbuilder2.setMessage("Stock Symbol "+tempStock.getStock_Symbol()+" is already displayed");

                                        alertbuilder2.show();
                                        return;
                                    }
                                }
                                StocksLoaderVolley.downloadStock(MainActivity.this, s);
                                stocksListAdapter.notifyItemRangeChanged(0,stockList.size());
                            }
                        });

                        builderS.setNegativeButton("NeverMind", (dialog1, p) -> {
                            dialog1.dismiss();
                        });

                        AlertDialog dialog1 = builderS.create();
                        dialog1.show();
                    }
                });

                builder.setNegativeButton("Cancel", (dialog, which) -> {
                    dialog.dismiss();
                });

                builder.setView(symbol2);
                builder.setTitle("STOCK SELECTION");
                builder.setMessage("Please enter a Stock Symbol");
                builder.show();
                return true;

            } else{
                AlertDialog.Builder alertbuilder1 = new AlertDialog.Builder(this);
                alertbuilder1.setTitle("No Network Connection");
                alertbuilder1.setMessage("Stocks Cannot Be Added Without A Network Connection");
                alertbuilder1.show();
                return true;
            }

        }
        else {
            return super.onOptionsItemSelected(item);
        }
    }


    @Override
    public void onClick(View v) {

        int position = recyclerView.getChildLayoutPosition(v);
        Stocks temp1 = stockList.get(position);

        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse(stockURL+temp1.getStock_Symbol()));

        startActivity(intent);

    }

    @Override
    public boolean onLongClick(View v) {
        int position = recyclerView.getChildLayoutPosition(v);

        currentStock = stockList.get(position);


        AlertDialog.Builder builder  = new AlertDialog.Builder(this);

        builder.setPositiveButton("DELETE",(dialog, which) -> {


            stockList.remove(position);

            stocksListAdapter.notifyItemRemoved(position);
            Collections.sort(stockList);
            try{
                FillJson();
            }catch (Exception e){
                e.printStackTrace();
            }

        });

        builder.setNegativeButton("NO",(dialog, which) -> {
            dialog.dismiss();
        });
        builder.setTitle(" Delete Stock Symbol  '"+ currentStock.getStock_Symbol()+"?" );


        AlertDialog dialog = builder.create();
        dialog.show();

        return true;
    }


    public  void readJson() throws IOException, JSONException {
        FileInputStream fis = getApplicationContext().openFileInput("JSONText.json");
        StringBuilder fileContent = new StringBuilder();

        byte[] buffer = new byte[1024];
        int n;
        while ((n = fis.read(buffer)) != -1)
        {
            fileContent.append(new String(buffer, 0, n));
        }
        JSONArray jsonArray = new JSONArray(fileContent.toString());
        Log.d(TAG, "readFromFile: ");
        stockList.clear();
        for (int i = 0; i < jsonArray.length(); i++) {
            stockList.add(Stocks.createFromJSON(jsonArray.getJSONObject(i)));
            stocksListAdapter.notifyItemInserted(i);
        }
        Collections.sort(stockList);

        Log.d(TAG, "readFromFile: ");


    }

    public void FillJson() throws JSONException,IOException {
        JSONArray jsonArray = new JSONArray();

        for (Stocks stock : stockList) {
            jsonArray.put(stock.toJSON());

        }
        stockList.size();
        FileOutputStream fos = getApplicationContext().openFileOutput("JSONText.json", MODE_PRIVATE);
        PrintWriter pr = new PrintWriter(fos);
        pr.println(jsonArray);
        pr.close();
        fos.close();

    }



}