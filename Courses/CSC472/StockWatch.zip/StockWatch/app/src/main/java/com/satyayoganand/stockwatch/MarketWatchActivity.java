package com.satyayoganand.stockwatch;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.net.Uri;
import android.net.http.SslError;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.webkit.SslErrorHandler;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.TextView;

public class MarketWatchActivity extends AppCompatActivity {
    private static final String TAG = "MarketWatchActivity";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_market_watch);

    }


    @SuppressLint("SetJavaScriptEnabled")
    public void doStock(View v) {
        String symbol = ((TextView) findViewById(R.id.Stock_Symbol)).getText().toString();
        if (symbol.trim().isEmpty()) {
            return;
        }

        String url = "https://www.marketwatch.com/investing/stock/" + symbol;
        WebView webView = findViewById(R.id.webView);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.setWebViewClient(new WebViewClient() {

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                Log.d(TAG, "onReceivedError: ");
                super.onReceivedError(view, request, error);
            }

            @Override
            public void onReceivedHttpError(WebView view, WebResourceRequest request, WebResourceResponse errorResponse) {
                Log.d(TAG, "onReceivedHttpError: " +
                        errorResponse.getStatusCode() + ": " +
                        errorResponse.getReasonPhrase() + " - " +
                        request.getUrl());
                super.onReceivedHttpError(view, request, errorResponse);
            }

            @Override
            public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError error) {
                Log.d(TAG, "onReceivedSslError: " +
                        error.getUrl());
                super.onReceivedSslError(view, handler, error);
            }
        });


        webView.loadUrl(Uri.parse(url).toString());
    }
}
