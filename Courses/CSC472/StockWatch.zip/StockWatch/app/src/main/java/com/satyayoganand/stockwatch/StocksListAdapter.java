package com.satyayoganand.stockwatch;

import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.Date;

public class StocksListAdapter extends RecyclerView.Adapter<StocksViewHolder>{


    private MainActivity mainActivity;
    private ArrayList<Stocks> stockArrayList;

    public StocksListAdapter(MainActivity mainActivity, ArrayList<Stocks> stockArrayList) {
        this.mainActivity = mainActivity;
        this.stockArrayList = stockArrayList;
    }


    @NonNull
    public StocksViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.stock_entry,parent,false);

        itemView.setOnClickListener(mainActivity);
        itemView.setOnLongClickListener(mainActivity);

        return new StocksViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull StocksViewHolder holder, int position) {

        Stocks stock = stockArrayList.get(position);

        String priceChange;
        if(stock.getChanged_Price()<=0.00) {

            holder.stockSymbol.setTextColor(Color.RED);
            holder.stockName.setTextColor(Color.RED);
            holder.lastTradePrice.setTextColor(Color.RED);
            holder.changeAmount.setTextColor(Color.RED);

            priceChange = "▼ " + stock.getChanged_Price() + " (" + stock.getChanged_Percent() + "%)";
        } else{

            holder.stockSymbol.setTextColor(Color.GREEN);
            holder.stockName.setTextColor(Color.GREEN);
            holder.lastTradePrice.setTextColor(Color.GREEN);
            holder.changeAmount.setTextColor(Color.GREEN);
            priceChange = "▲ " + stock.getChanged_Price() + " (" + stock.getChanged_Percent() + "%)";
        }

        holder.stockSymbol.setText(stock.getStock_Symbol());
        holder.stockName.setText(stock.getStock_Name());
        holder.lastTradePrice.setText(String.valueOf(stock.getLast_Trade_Price()));
        holder.changeAmount.setText(priceChange);


    }

    @Override
    public int getItemCount() {
        return stockArrayList.size();
    }



}
