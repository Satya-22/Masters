package com.satyayoganand.stockwatch;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.Serializable;
import java.text.DecimalFormat;

public class Stocks implements Comparable<Stocks>, Serializable {


    private String stock_Symbol;
    private String stock_Name;
    private Double last_Trade_Price;
    private Double changed_Price;
    private Double changed_Percent;
    private static final DecimalFormat decimalFormat = new DecimalFormat("0.00");

    public Stocks(String stockSymbol,String stockName,Double lastTradePrice,Double changedPrice,Double changed_Percent){
        this.stock_Symbol = stockSymbol;
        this.stock_Name = stockName;
        this.last_Trade_Price = Double.valueOf(decimalFormat.format(lastTradePrice));
        this.changed_Price = Double.valueOf(decimalFormat.format(changedPrice));
        this.changed_Percent = Double.valueOf(decimalFormat.format(changed_Percent));
    }
    public Double getChanged_Percent() {
        return changed_Percent;
    }

    public Double getLast_Trade_Price() {
        return last_Trade_Price;
    }


    public Double getChanged_Price() {
        return changed_Price;
    }


    public String getStock_Symbol() {
        return stock_Symbol;
    }


    public String getStock_Name() {
        return stock_Name;
    }


    public JSONObject toJSON() throws JSONException {
        JSONObject note = new JSONObject();

        note.put("Symbol", stock_Symbol);
        note.put("name", stock_Name);
        note.put("latestPrice", 0.00);
        note.put("changedPrice",0.00);
        note.put("changePercent",0.00);
        return note;
    }

    public static Stocks createFromJSON(JSONObject jsonObject) throws JSONException {
        String Symbol = jsonObject.getString("Symbol");
        String Name = jsonObject.getString("name");
        Double latestPrice = jsonObject.getDouble("latestPrice");
        Double changedPrice = jsonObject.getDouble("changedPrice");
        Double changePercent = jsonObject.getDouble("changePercent");

        return new Stocks(Symbol,Name,latestPrice,changedPrice ,changePercent);
    }

    @Override
    public int compareTo(Stocks stocks) {
        return stock_Symbol.compareTo(stocks.stock_Symbol);
    }
}
