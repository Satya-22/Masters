package com.satyayoganand.stockwatch;

import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class StocksViewHolder extends RecyclerView.ViewHolder {
    TextView stockSymbol;
    TextView stockName;
    TextView lastTradePrice;
    TextView changeAmount;
    public StocksViewHolder(@NonNull View itemView) {
        super(itemView);
        stockSymbol = itemView.findViewById(R.id.Stock_Symbol);
        stockName = itemView.findViewById(R.id.Stock_Name);
        lastTradePrice = itemView.findViewById(R.id.last_Trade);
        changeAmount = itemView.findViewById(R.id.price_Change);
    }
}
