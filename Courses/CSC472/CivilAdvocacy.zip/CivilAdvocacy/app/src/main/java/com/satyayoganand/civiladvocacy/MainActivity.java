package com.satyayoganand.civiladvocacy;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.text.InputType;
import android.util.Log;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;


public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private static final String TAG = "MainActivity";

    public static ArrayList<Civics> CivicList = new ArrayList<>();
    public TextView currentLocation;
    public TextView networkConnection;
    private RecyclerView recyclerView;
    public static CivicListAdapter civicListAdapter;
    private ActivityResultLauncher<Intent> activityResultLauncher;
    private Civics currentCivic;
    private EditText search;
    private String searchText;


    private FusedLocationProviderClient fusedLocationClient;
    private static final int LOCATION_REQUEST = 111;

    private static String locationString = "Unspecified Location";

    @SuppressLint({"SetTextI18n", "MissingInflatedId"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        networkConnection = findViewById(R.id.Network);
        currentLocation = findViewById(R.id.Location);
        if(hasNetworkConnection()) {
            networkConnection.setVisibility(View.GONE);
            fusedLocationClient =
                    LocationServices.getFusedLocationProviderClient(this);
            determineLocation();
            //currentLocation.setText("831S,Bishop Street,Little Italy,Chicago,60607");
            recyclerView = findViewById(R.id.Recycler);
            civicListAdapter = new CivicListAdapter(this, CivicList);
            recyclerView.setAdapter(civicListAdapter);
            recyclerView.setLayoutManager(new LinearLayoutManager(this));
            Log.d(TAG, "onCreate: Location String " + locationString);

            activityResultLauncher = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), this::handleResult);
        }
        else{
            Log.d(TAG, "onCreate: Has No Network Connection");
            currentLocation.setText("No Network Connection");
            networkConnection.setVisibility(View.VISIBLE);

        }

    }
    private boolean hasNetworkConnection() {
        ConnectivityManager connectivityManager = getSystemService(ConnectivityManager.class);
        NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();
        return (networkInfo != null && networkInfo.isConnectedOrConnecting());
    }
    public void handleResult(ActivityResult result) {
    }
    private void determineLocation() {
        // Check perm - if not then start the  request and return
        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, LOCATION_REQUEST);
            return;
        }
        fusedLocationClient.getLastLocation()
                .addOnSuccessListener(this, location -> {
                    // Got last known location. In some situations this can be null.
                    if (location != null) {
                        locationString = getLocation(location);
                        currentLocation.setText(locationString);
                        CivicDataDownloader.getCivicOfficialsData(this,CivicList,locationString);
                        civicListAdapter.notifyItemRangeChanged(0,CivicList.size());
                    }
                })
                .addOnFailureListener(this, e ->
                        Toast.makeText(MainActivity.this,
                                e.getMessage(), Toast.LENGTH_LONG).show());
    }

    @SuppressLint("SetTextI18n")
    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {

        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == LOCATION_REQUEST) {
            if (permissions[0].equals(Manifest.permission.ACCESS_FINE_LOCATION)) {
                if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    determineLocation();
                } else {
                    currentLocation.setText("Location permission was denied - cannot determine address");
                }
            }
        }
    }
    private String getLocation(Location loc) {

        StringBuilder sb = new StringBuilder();

        Geocoder geocoder = new Geocoder(this, Locale.getDefault());
        List<Address> addresses;

        try {
            addresses = geocoder.getFromLocation(loc.getLatitude(), loc.getLongitude(), 1);
            String city = addresses.get(0).getLocality();
            String state = addresses.get(0).getAdminArea();
            sb.append(String.format(
                    Locale.getDefault(),
                    "%s, %s%n%nProvider: %s%n%n%.5f, %.5f",
                    city, state, loc.getProvider(), loc.getLatitude(), loc.getLongitude()));
        } catch (IOException e) {
            e.printStackTrace();
        }
        return sb.toString();
    }
    @Override
    public boolean onCreateOptionsMenu(@NonNull Menu menu) {
        getMenuInflater().inflate(R.menu.entry_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        if (item.getItemId() == R.id.About) {
            Intent intent = new Intent(this, CivicAbout.class);
            startActivity(intent);
            return true;
        }
        else if (item.getItemId() == R.id.Search) {
            search = new EditText(this);
           // search.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS);
            search.setGravity(Gravity.CENTER);

            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setPositiveButton("ok", (dialog, which) -> {
                locationString = search.getText().toString();
                Log.d(TAG, "onOptionsItemSelected: Search Button  "+ locationString);
                currentLocation.setText(locationString);
                CivicDataDownloader.getCivicOfficialsData(this,CivicList,locationString);
                civicListAdapter.notifyItemRangeChanged(0,CivicList.size());

            });
            builder.setNegativeButton("Cancel", (dialog, which) -> {
                dialog.dismiss();
            });
            builder.setView(search);
            builder.setTitle("Enter Address ");
            builder.show();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
    @Override
    public void onClick (View v){
        Log.d(TAG, "onClick: ");
        Intent intent = new Intent(this, CivicDetails.class);

        int pos = recyclerView.getChildLayoutPosition(v);
        currentCivic = CivicList.get(pos);

        intent.putExtra("CIVIC_DETAILS", currentCivic);
        intent.putExtra("Location", locationString);

        activityResultLauncher.launch(intent);
    }
}

