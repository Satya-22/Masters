package com.satyayoganand.civiladvocacy;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.Callback;
import com.squareup.picasso.Picasso;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class CivicListAdapter  extends RecyclerView.Adapter<CivicViewHolder> {
    private static final String TAG = "CivicListAdapter";

    private MainActivity mainActivity;
    private ArrayList<Civics> civicArrayList;

    public CivicListAdapter(MainActivity mainActivity, ArrayList<Civics> civicsArrayList) {
        this.mainActivity = mainActivity;
        this.civicArrayList = civicsArrayList;
    }

    @NonNull
    @Override
    public CivicViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.list_entry, parent, false);
        itemView.setOnClickListener(mainActivity);
        return new CivicViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull CivicViewHolder holder, int position) {
        Log.d(TAG, "onBindViewHolder: ");

        Civics civic = civicArrayList.get(position);
        holder.civicName.setText(civic.getCivicName());
        holder.civicPosition.setText(civic.getCivicPosition());
        Log.d(TAG, "onBindViewHolder Civic Photo: " + civic.getCivicPhoto());
        if(civic.getCivicPhoto() != "") {
            Picasso.get().load(civic.getCivicPhoto()).placeholder(R.drawable.missing).error(R.drawable.brokenimage)
                    .into(holder.civicImage);
        }
        else{
            Picasso.get().load(R.drawable.missing).into(holder.civicImage);
        }
    }

    @Override
    public int getItemCount() {
        return civicArrayList.size();
    }
}
