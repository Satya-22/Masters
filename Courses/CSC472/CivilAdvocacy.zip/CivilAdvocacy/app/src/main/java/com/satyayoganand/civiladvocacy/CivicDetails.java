package com.satyayoganand.civiladvocacy;

import androidx.appcompat.app.AppCompatActivity;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.text.util.Linkify;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import com.squareup.picasso.Picasso;

import java.util.Locale;

public class CivicDetails extends AppCompatActivity implements View.OnClickListener{
    private static final String TAG = "CivicDetails";
    private TextView civicName;
    private TextView civicPosition;
    private TextView address;
    private TextView emailAddress;
    private TextView phoneNumber;
    private TextView website;
    private TextView location;
    private ImageView civicPhoto;
    private ImageView civicPartyIcon;
    private TextView civicPartyNameText;

    private TextView address_Text;
    private TextView email_Text;
    private TextView phone_Text;
    private TextView website_Text;



    private String civic_Name;
    private String civic_Position;
    private String address_Info;
    private String emailAddress_Info;
    private String phoneNumber_Info;
    private String website_Info;
    private String partyName_Info;
    private String civic_Photo_Url;
    private String dem_Party_WebURL;
    private String rep_Party_WebURL;
    public boolean imageLoaded = true;
    private String locationString;
    private int color;

    @SuppressLint({"MissingInflatedId", "CutPasteId"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_civic_details);
        locationString = (String) getIntent().getSerializableExtra("Location");
        Log.d(TAG, "onCreate: Location String " + locationString);
        Civics N = (Civics) getIntent().getSerializableExtra("CIVIC_DETAILS");
        civicPhoto = findViewById(R.id.Official_Image);
        civicPartyIcon = findViewById(R.id.Party_Icon);
        civicPartyNameText = findViewById(R.id.PartyName);
        civicPartyNameText.setText("(" + N.getCivicPartyName() + ")");

        Log.d(TAG, "onCreate: Party Name " + N.getCivicPartyName());
        if(N.getCivicPartyName().equals("Republican Party")){
            setActivityBackgroundColor(Color.parseColor("#09e1003"));
            if(N.getCivicPhoto() != "") {
                Picasso.get().load(N.getCivicPhoto()).placeholder(R.drawable.missing).error(R.drawable.brokenimage)
                        .into(civicPhoto);
            }
            else{
                Picasso.get().load(R.drawable.missing).into(civicPhoto);
            }
            Picasso.get().load(R.drawable.rep_logo).into(civicPartyIcon);
            rep_Party_WebURL = "https://www.gop.com/";
            civicPartyIcon.setOnClickListener(view -> {

                Intent intent;
                intent = new Intent(Intent.ACTION_VIEW, Uri.parse(rep_Party_WebURL));
                startActivity(intent);
            });

        }
        else if(N.getCivicPartyName().toUpperCase(Locale.ROOT).contains("Demo".toUpperCase(Locale.ROOT))){
            if(N.getCivicPhoto() != "") {
                Picasso.get().load(N.getCivicPhoto()).placeholder(R.drawable.missing)
                        .error(R.drawable.brokenimage)
                        .into(civicPhoto);
            }
            else{
                Picasso.get().load(R.drawable.missing).into(civicPhoto);
            }
            setActivityBackgroundColor(Color.parseColor("#072066"));
            Picasso.get().load(R.drawable.dem_logo).into(civicPartyIcon);
            dem_Party_WebURL = "https://democrats.org/";
            civicPartyIcon.setOnClickListener(view -> {

                Intent intent;
                intent = new Intent(Intent.ACTION_VIEW, Uri.parse(dem_Party_WebURL));
                startActivity(intent);
            });
        }
        else{
            setActivityBackgroundColor(Color.BLACK);
            civicPartyIcon.setVisibility(View.GONE);
        }

        civicPhoto = findViewById(R.id.Official_Image);
        civic_Photo_Url = N.getCivicPhoto();

        civicName = findViewById(R.id.Civic_Name);
        civicPosition = findViewById(R.id.Civic_Position);
        location = findViewById(R.id.CivicLocation);

        address_Text = findViewById(R.id.Address);
        address = findViewById(R.id.Address_Info);

        email_Text = findViewById(R.id.Email);
        emailAddress = findViewById(R.id.Email_Info);

        phone_Text = findViewById(R.id.Phone);
        phoneNumber = findViewById(R.id.Phone_Info);

        website_Text = findViewById(R.id.Website);
        website = findViewById(R.id.Website_Info);

        civic_Name = N.getCivicName();
        System.out.println("Print Civic Name");
        civicName.setText(civic_Name);

        civic_Position = N.getCivicPosition();
        System.out.println("Print Civic Position");
        civicPosition.setText(civic_Position);

        partyName_Info = N.getCivicPartyName();
        System.out.println("Print Civic Location");
        location.setText(locationString);

        address_Info = N.getAddress();

        System.out.println("Address Info : "+ address_Info);
        if(address_Info.isEmpty()){
            address.setVisibility(View.GONE);
            address_Text.setVisibility(View.GONE);
        }
        else{
            address.setText(address_Info);
            address.setOnClickListener(View -> {
                    Uri mapUri = Uri.parse("geo:0,0?q=" + Uri.encode(address_Info));
            Intent intent = new Intent(Intent.ACTION_VIEW, mapUri);
            startActivity(intent);

        });
        }
        emailAddress_Info = N.getEmailAddress();
        System.out.println("Email Address Info : "+ emailAddress_Info);
        if(emailAddress_Info.isEmpty()) {
            emailAddress.setVisibility(View.GONE);
            email_Text.setVisibility(View.GONE);
        }
        else{
            emailAddress.setText(emailAddress_Info);
            Linkify.addLinks(emailAddress, Linkify.EMAIL_ADDRESSES);
        }
        phoneNumber_Info = N.getPhoneNumber();
        System.out.println("PhoneNumber Info : "+ phoneNumber_Info);
        if(phoneNumber_Info.isEmpty()) {
            phoneNumber.setVisibility(View.GONE);
            phone_Text.setVisibility(View.GONE);
        }
        else{
            phoneNumber.setText(phoneNumber_Info);
            Linkify.addLinks(phoneNumber, Linkify.ALL);
        }
        website_Info = N.getWebPageLink();
        System.out.println("WebPage Info : "+ website_Info);
        if(website_Info.isEmpty()){
            website.setVisibility(View.GONE);
            website_Text.setVisibility(View.GONE);
        }
        else{
            website.setText(website_Info);
            Linkify.addLinks(website, Linkify.ALL);
        }
        ImageView imageFacebook = findViewById(R.id.facebookButton);
        ImageView imageYouTube = findViewById(R.id.youtubeButton);
        ImageView imageTwitter = findViewById(R.id.twitterButton);
        ImageView imageOfficialPhoto = findViewById(R.id.Official_Image);

        Log.d(TAG, "onCreate: Links:" + "Facebook :"+N.getFacebookLink()+"Youtube"+N.getYoutubeLink()+"Twitter"+N.getTwitterLink());
        if(!N.getCivicPhoto().equals("")) {
            imageOfficialPhoto.setOnClickListener(view -> {

                Intent intent = new Intent(this, PhotoDetailActivity.class);
                intent.putExtra("CIVIC_DETAILS", N);
                intent.putExtra("LOCATION",locationString);
                startActivity(intent);
            });
        }
        if(!N.getFacebookLink().equals("")) {
            imageFacebook.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intent;
                    try {
                        getPackageManager().getPackageInfo("com.facebook.katana", 0);
                        intent = new Intent(Intent.ACTION_VIEW, Uri.parse("fb://facewebmodel/f?href=" + N.getFacebookLink()));
                    } catch (Exception e) {
                        intent = new Intent(Intent.ACTION_VIEW, Uri.parse("http://www.facebook.com/" + N.getFacebookLink()));
                    }
                    startActivity(intent);
                }
            });
        }else{
            imageFacebook.setVisibility(View.GONE);
        }


        if(!N.getYoutubeLink().equals("")) {
            imageYouTube.setOnClickListener(view -> {
                Intent intent;
                try {
                    intent = new Intent(Intent.ACTION_VIEW);
                    intent.setPackage("com.google.android.youtube");
                    intent.setData(Uri.parse("http://www.youtube.com/" + N.getYoutubeLink()));
                    startActivity(intent);
                } catch (Exception e) {
                    intent = new Intent(Intent.ACTION_VIEW, Uri.parse("http://www.youtube.com/" + N.getYoutubeLink()));
                    startActivity(intent);
                }

            });
        }else{
            imageYouTube.setVisibility(View.GONE);
        }


        if(!N.getTwitterLink().equals("")) {
            imageTwitter.setOnClickListener(view -> {
                String twitterAppUrl = "twitter://user?screen_name=" + N.getTwitterLink();
                String twitterWebUrl = "https://twitter.com/" + N.getTwitterLink();

                Intent intent;
                try {
                    getPackageManager().getPackageInfo("com.twitter.android", 0);
                    intent = new Intent(Intent.ACTION_VIEW, Uri.parse(twitterAppUrl));
                } catch (Exception e) {
                    intent = new Intent(Intent.ACTION_VIEW, Uri.parse(twitterWebUrl));
                }
                intent = new Intent(Intent.ACTION_VIEW, Uri.parse(twitterWebUrl));
                startActivity(intent);
            });
        }else {
            imageTwitter.setVisibility(View.GONE);
        }

    }

    public void setActivityBackgroundColor(int color){
        this.color = color;
        View v = this.getWindow().getDecorView();
        v.setBackgroundColor(color);
    }

    @Override
    public void onClick(View v) {

    }
}