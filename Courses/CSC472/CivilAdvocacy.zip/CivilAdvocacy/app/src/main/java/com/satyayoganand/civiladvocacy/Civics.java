package com.satyayoganand.civiladvocacy;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.Serializable;

public class Civics implements Serializable {



    private String civicName;
    private String civicPosition;
    private String civicPartyName;
    private String emailAddress;
    private String address;
    private String phoneNumber;
    private String webPageLink;
    private String facebookLink;
    private String youtubeLink;
    private String twitterLink;
    private String civicPhoto;


    private String location;


    public Civics(String civicName, String civicPosition,String civicPartyName,String address,String phoneNumber,String emailAddress,String webPageLink,String facebookLink,String youtubeLink,String twitterLink,String civicPhoto) {
        this.civicName = civicName;
        this.civicPosition = civicPosition;
        this.civicPartyName = civicPartyName;
        this.address = address;
        this.phoneNumber = phoneNumber;
        this.emailAddress = emailAddress;
        this.webPageLink = webPageLink;
        this.facebookLink = facebookLink;
        this.youtubeLink = youtubeLink;
        this.twitterLink = twitterLink;
        this.civicPhoto = civicPhoto;

    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }


    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getEmailAddress() {
        return emailAddress;
    }

    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getWebPageLink() {
        return webPageLink;
    }

    public void setWebPageLink(String webPageLink) {
        this.webPageLink = webPageLink;
    }

    public String getFacebookLink() {
        return facebookLink;
    }

    public void setFacebookLink(String facebookLink) {
        this.facebookLink = facebookLink;
    }

    public String getYoutubeLink() {
        return youtubeLink;
    }

    public void setYoutubeLink(String youtubeLink) {
        this.youtubeLink = youtubeLink;
    }

    public String getTwitterLink() {
        return twitterLink;
    }

    public void setTwitterLink(String twitterLink) {
        this.twitterLink = twitterLink;
    }

    public String getCivicName() {
        return civicName;
    }

    public void setCivicName(String civicName) {
        this.civicName = civicName;
    }

    public String getCivicPosition() {
        return civicPosition;
    }

    public void setCivicPosition(String civicPosition) {
        this.civicPosition = civicPosition;
    }

    public String getCivicPartyName() {
        return civicPartyName;
    }

    public void setCivicPartyName(String civicPartyName) {
        this.civicPartyName = civicPartyName;
    }

    public String getCivicPhoto() {
        return civicPhoto;
    }

    public void setCivicPhoto(String civicPhoto) {
        this.civicPhoto = civicPhoto;
    }
}
