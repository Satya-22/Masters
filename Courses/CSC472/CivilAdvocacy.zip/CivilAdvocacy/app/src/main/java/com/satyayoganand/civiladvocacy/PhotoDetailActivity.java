package com.satyayoganand.civiladvocacy;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.Locale;

public class PhotoDetailActivity extends AppCompatActivity {
    private static final String TAG = "PhotoDetailActivity";
    private TextView Official_Name;
    private TextView Official_Position;
    private ImageView Official_Photo;
    private ImageView civicPartyIcon;
    private TextView location;


    private String rep_Party_WebURL;
    private String dem_Party_WebURL;
    private int color;
    private String locationString;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_photo_detail);

        Civics N = (Civics) getIntent().getSerializableExtra("CIVIC_DETAILS");
        civicPartyIcon = findViewById(R.id.Party_Image_Photo_Activity);
        locationString = (String) getIntent().getSerializableExtra("LOCATION");
        Official_Photo = findViewById(R.id.Official_Image_Photo_Activity);
        location = findViewById(R.id.Location_Photo_Activity);
        location.setText(locationString);

        Log.d(TAG, "onCreate: Party Name " + N.getCivicPartyName());
        if(N.getCivicPartyName().equals("Republican Party")){
            setActivityBackgroundColor(Color.parseColor("#09e1003"));
            if(N.getCivicPhoto() != "") {
                Picasso.get().load(N.getCivicPhoto()).placeholder(R.drawable.missing).error(R.drawable.brokenimage)
                        .into(Official_Photo);
            }
            Picasso.get().load(R.drawable.rep_logo).into(civicPartyIcon);
            rep_Party_WebURL = "https://www.gop.com/";
            civicPartyIcon.setOnClickListener(view -> {

                Intent intent;
                intent = new Intent(Intent.ACTION_VIEW, Uri.parse(rep_Party_WebURL));
                startActivity(intent);
            });

        }
        else if(N.getCivicPartyName().toUpperCase(Locale.ROOT).contains("Demo".toUpperCase(Locale.ROOT))){

            setActivityBackgroundColor(Color.parseColor("#072066"));
            if(!N.getCivicPhoto().equals("")) {
                Picasso.get().load(N.getCivicPhoto()).placeholder(R.drawable.missing).error(R.drawable.brokenimage)
                        .into(Official_Photo);
            }
            else{
                Picasso.get().load(R.drawable.missing).into(Official_Photo);
            }
            Picasso.get().load(R.drawable.dem_logo).into(civicPartyIcon);
            dem_Party_WebURL = "https://democrats.org/";
            civicPartyIcon.setOnClickListener(view -> {

                Intent intent;
                intent = new Intent(Intent.ACTION_VIEW, Uri.parse(dem_Party_WebURL));
                startActivity(intent);
            });
        }
        else{
            setActivityBackgroundColor(Color.BLACK);
            civicPartyIcon.setVisibility(View.GONE);
        }

        Official_Name = findViewById(R.id.Official_Name_Photo_Activity);
        Official_Name.setText(N.getCivicName());

        Official_Position = findViewById(R.id.Official_Position_Photo_Activity);
        Official_Position.setText(N.getCivicPosition());

        ImageView imageButtonPartyIcon = findViewById(R.id.Party_Image_Photo_Activity);
        imageButtonPartyIcon.setOnClickListener(view -> {

            Intent intent;
            String FACEBOOK_URL = "https://www.google.com/";
            intent = new Intent(Intent.ACTION_VIEW, Uri.parse(FACEBOOK_URL));
            startActivity(intent);
        });
    }
    public void setActivityBackgroundColor(int color){
        this.color = color;
        View v = this.getWindow().getDecorView();
        v.setBackgroundColor(color);
    }
}