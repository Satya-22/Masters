package com.satyayoganand.civiladvocacy;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.text.util.Linkify;
import android.widget.TextView;

public class CivicAbout extends AppCompatActivity {
    private TextView civic_Api_Link;
    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_civic_about);
        civic_Api_Link = findViewById(R.id.Civic_Link);
        civic_Api_Link.setText("https://developers.google.com/civic-information/");
        Linkify.addLinks(civic_Api_Link,Linkify.WEB_URLS);
    }
}