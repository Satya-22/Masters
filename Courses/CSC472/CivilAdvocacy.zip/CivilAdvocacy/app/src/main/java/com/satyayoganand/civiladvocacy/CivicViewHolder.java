package com.satyayoganand.civiladvocacy;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class CivicViewHolder extends RecyclerView.ViewHolder {

    TextView civicName;
    TextView civicPosition;
    ImageView civicImage;

    public CivicViewHolder(@NonNull View itemView) {
        super(itemView);

        civicName = itemView.findViewById(R.id.Official_name);
        civicPosition = itemView.findViewById(R.id.Official_position);
        civicImage = itemView.findViewById(R.id.Official_image);
    }
}
