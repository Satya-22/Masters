package com.satyayoganand.civiladvocacy;

import android.net.Uri;
import android.util.Log;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;

public class CivicDataDownloader {

    private static final String TAG = "CivicDataDownloader";
    private static RequestQueue queue;
    private static MainActivity mainActivity;
    private static final String CIVIC_DATA_URL = "https://www.googleapis.com/civicinfo/v2/representatives";
    private static final String api_Key = "AIzaSyDMGscoQq3qr7zrtv2aQ4GCVOk3_v4Ll-8";

    public static void getCivicOfficialsData(MainActivity mainActivity1, ArrayList<Civics> officialArrayList,String location) {


        mainActivity = mainActivity1;
        MainActivity.CivicList.clear();
        RequestQueue queue = Volley.newRequestQueue(mainActivity);

        Uri.Builder buildURL = Uri.parse(CIVIC_DATA_URL).buildUpon();
        buildURL.appendQueryParameter("key", api_Key);
        Log.d(TAG, "getCivicOfficialsData: " + location);
        buildURL.appendQueryParameter("address",location);

        String urlToUse = buildURL.build().toString();

        Response.Listener<JSONObject> listener = response -> parseJSON(response,officialArrayList);

        Response.ErrorListener error = error1 -> parseJSON(null,officialArrayList);

        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, urlToUse, null, listener, error);

        queue.add(jsonObjectRequest);

    }

    private static void parseJSON (JSONObject jsonObject, ArrayList<Civics> officialArrayList) {

        try {

            JSONObject jMain = jsonObject.getJSONObject("normalizedInput");
            StringBuilder location = new StringBuilder();

            String city = jMain.getString("city");
            String state = jMain.getString("state");
            String zip = jMain.getString("zip");
            location.append(city+", "+state+", "+zip);

            JSONArray officesArray = jsonObject.getJSONArray("offices");

            JSONArray officialsArray = jsonObject.getJSONArray("officials");

            for(int i=0;i<officesArray.length();i++) {
                officesArray.length();

                JSONObject jOfficial = officesArray.getJSONObject(i);
                String civicPosition = jOfficial.getString("name");

                JSONArray officialIndexes = jOfficial.getJSONArray("officialIndices");
                for(int d=0;d<officialIndexes.length();d++){

                    String civicName="";
                    String civicAddress="";
                    String civicPartyName="";
                    String civicPhoneNumber="";
                    String civicWebsite="";
                    String civicEmailAddress="";
                    String civicFacebookPage="";
                    String civicTwitterHandle="";
                    String civicYoutubeLink="";
                    String civicImage="";
                    String official_Index;

                    JSONArray phoneNumber;
                    JSONArray mailAddress;
                    JSONArray url_Links;
                    JSONArray addresses;

                    official_Index = officialIndexes.getString(d);
                    int j = Integer.parseInt(official_Index);
                    JSONObject jsonObject1 = officialsArray.getJSONObject(j);
                    civicName = jsonObject1.getString("name");


                    JSONObject addressObject;

                    if(jsonObject1.has("address")) {
                        addresses = jsonObject1.getJSONArray("address");
                        if(addresses.length()>0) {
                            addressObject = addresses.getJSONObject(0);
                            JSONArray keys = addressObject.names ();



                            for (int k = 0; k < keys.length (); k++) {

                                String key = keys.getString (k);
                                civicAddress = civicAddress +addressObject.getString (key);
                                if(k!=keys.length()-1){
                                    civicAddress = civicAddress+" , ";
                                }
                            }
                        }
                    }

                    if(jsonObject1.has("party")) {
                        civicPartyName = jsonObject1.getString("party");
                    }


                    if(jsonObject1.has("phones")) {
                        phoneNumber = jsonObject1.getJSONArray("phones");
                        if(phoneNumber.length()>0) {
                            civicPhoneNumber = phoneNumber.getString(0);
                        }
                    }

                    if(jsonObject1.has("urls")) {
                        url_Links = jsonObject1.getJSONArray("urls");
                        if (url_Links.length() > 0) {
                            civicWebsite = url_Links.getString(0);
                        }
                    }

                    if(jsonObject1.has("emails")) {
                        mailAddress = jsonObject1.getJSONArray("emails");
                        if(mailAddress.length()>0) {
                            civicEmailAddress = mailAddress.getString(0);
                        }
                    }


                    if(jsonObject1.has("photoUrl")) {
                        civicImage = jsonObject1.getString("photoUrl");
                    }

                    if(jsonObject1.has("channels")){
                        JSONArray channelArray = jsonObject1.getJSONArray("channels");
                        for(int k=0;k<channelArray.length();k++) {
                            JSONObject channelObject = channelArray.getJSONObject(k);
                            String type = channelObject.getString("type");
                            if(type.equals("Facebook")){
                                civicFacebookPage = channelObject.getString("id");
                            }
                            if(type.equals("Twitter")){
                                civicTwitterHandle = channelObject.getString("id");
                            }
                            if(type.equals("Youtube")){
                                civicYoutubeLink = channelObject.getString("id");
                            }
                        }
                    }
                    System.out.println("Facebook :"+civicFacebookPage);
                    System.out.println("YOUTUBE :"+civicYoutubeLink);
                    System.out.println("TW :"+civicTwitterHandle);
                    System.out.println("---------------------------");
                    officialArrayList.add(new Civics(civicName, civicPosition, civicPartyName, civicAddress, civicPhoneNumber, civicEmailAddress, civicWebsite, civicFacebookPage, civicYoutubeLink,civicTwitterHandle, civicImage));
                }

                MainActivity.civicListAdapter.notifyItemRangeChanged(0,officialArrayList.size());


            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


}