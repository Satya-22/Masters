package com.satyayoganand.tipsplit;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import android.annotation.SuppressLint;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import java.text.MessageFormat;

public class MainActivity extends AppCompatActivity {
    private static final String TAG = "MainActivity";
    private EditText billamount;
    private EditText numberofPeople;
    private TextView tipAmount;
    private TextView totalWithTip;
    private TextView totalPerPerson;
    private static double billWithTipVal;
    private static int tipPercentVal;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        billamount = findViewById(R.id.billAmount);
        tipAmount = findViewById(R.id.tipAmount);
        totalWithTip = findViewById(R.id.tipTotal);
        numberofPeople = findViewById(R.id.numberOfPeople);
        totalPerPerson = findViewById(R.id.totalPerperson);

    }

    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putString("TipAmount",tipAmount.getText().toString());
        outState.putString("TipTotal",totalWithTip.getText().toString());
        outState.putString("TotalPerPerson",totalPerPerson.getText().toString());
    }

    @Override
    protected void onRestoreInstanceState(@NonNull Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);

        if(savedInstanceState.containsKey("TipAmount")){
            tipAmount.setText(savedInstanceState.getString("TipAmount"));
        }
        if(savedInstanceState.containsKey("TipTotal")){
            totalWithTip.setText(savedInstanceState.getString("TipTotal"));
        }
        if(savedInstanceState.containsKey("TipTotal")){
            totalPerPerson.setText(savedInstanceState.getString("TotalPerPerson"));
        }
    }

    @SuppressLint("DefaultLocale")
    public void doPerPersonCalc(View v){
        Log.d(TAG, "tipCalc: Clicked Go Button ");


        String numberOfPeople = numberofPeople.getText().toString();

        if(numberOfPeople.isEmpty())
        {
            return;
        }

        int numberOfPeopleVal = Integer.parseInt(numberOfPeople);
        Log.d(TAG, "tipCalc: TipPercent is not Null");

        if(numberOfPeopleVal != 0) {

            double totalPerPersonVal = billWithTipVal / numberOfPeopleVal;
            totalPerPersonVal = Math.round(totalPerPersonVal * 100.0) / 100.0;
            Log.d(TAG, "tipCalc: Amount per Person : " + totalPerPersonVal);
            totalPerPerson.setText(MessageFormat.format("${0}", String.format("%.2f", totalPerPersonVal)));

        }
        else{
            totalPerPerson.setText("");
        }

    }

    @SuppressLint("DefaultLocale")
    public void doCalcTotalTip(View v){

        String billAmount = billamount.getText().toString();
        if(billAmount.startsWith("$")) {
            billAmount = billAmount.substring(1);
        }

        if(!billAmount.isEmpty()) {


            double billAmountVal = Double.parseDouble(billAmount);
            billAmountVal = Math.round(billAmountVal * 100.0) / 100.0;


            Log.d(TAG, "tipCalc: BillAmount is not Null");

            if (v.getId() == R.id.radioButton12) {
                tipPercentVal = 12;
                Log.d(TAG, "Tip: Radio Button 12% Selected " + ((RadioButton) v).getText().toString());
                doTipAmountCalc(billAmountVal);
            } else if (v.getId() == R.id.radioButton15) {
                tipPercentVal = 15;
                Log.d(TAG, "Tip: Radio Button 15% Selected " + ((RadioButton) v).getText().toString());
                doTipAmountCalc(billAmountVal);
            } else if (v.getId() == R.id.radioButton18) {
                tipPercentVal = 18;
                Log.d(TAG, "Tip: Radio Button 18% Selected " + ((RadioButton) v).getText().toString());
                doTipAmountCalc(billAmountVal);
            } else if (v.getId() == R.id.radioButton20) {
                tipPercentVal = 20;
                Log.d(TAG, "Tip: Radio Button 20% Selected " + ((RadioButton) v).getText().toString());
                doTipAmountCalc(billAmountVal);
            }
            billamount.setText(MessageFormat.format("${0}", String.format("%.2f", billAmountVal)));
        }
        else{doClear(v);
            return;}
    }

    @SuppressLint("DefaultLocale")
    public void doTipAmountCalc(double billAmountVal){

        double tipAmountVal;

        tipAmountVal = (billAmountVal * tipPercentVal) / 100;
        tipAmountVal = Math.round(tipAmountVal * 100.0) / 100.0;
        Log.d(TAG, "tipCalc: Tip Amount " + tipAmountVal);

        tipAmount.setText(MessageFormat.format("${0}", String.format("%.2f", tipAmountVal)));

        billWithTipVal = billAmountVal + tipAmountVal;
        billWithTipVal = Math.round(billWithTipVal * 100.0) / 100.0;
        Log.d(TAG, "tipCalc: Total with Tip : " + billWithTipVal);
        totalWithTip.setText(MessageFormat.format("${0}", String.format("%.2f", billWithTipVal)));

    }

    public void doClear(View v){

        billamount.setText("");
        tipAmount.setText("");
        totalWithTip.setText("");
        RadioGroup radioGrp = findViewById(R.id.RadioGroup);
        radioGrp.clearCheck();
        numberofPeople.setText("");
        totalPerPerson.setText("");
    }
}